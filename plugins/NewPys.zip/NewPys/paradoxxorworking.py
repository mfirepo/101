import sys
import urllib.request
import urllib.parse
import urllib.error
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import re
import time
import json
import os

try:
    import inputstreamhelper
    HAS_INPUTSTREAM_HELPER = True
except ImportError:
    HAS_INPUTSTREAM_HELPER = False

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
HANDLE = int(sys.argv[1])

ADDON_ICON = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}/icon.png")
ADDON_FANART = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}/fanart.jpg")

CACHE_DURATION = 12 * 60 * 60
CACHE_DIR = xbmcvfs.translatePath(f"special://userdata/addon_data/{ADDON_ID}/")
CACHE_FILE = os.path.join(CACHE_DIR, "playlist_cache.dat")

XOR_KEY = b"k5F9#mR2@qW8!zX0$vB7%nC1^aD3&sE4*lG6(jH0)pK9_yL2"

PLAYLIST_SOURCES = {
    "[COLORlime]24 TV[/COLOR]": "https://raw.githubusercontent.com/BuddyChewChew/My-Streams/refs/heads/main/TheTVApp.m3u8",
    "[COLORlime]Neo TV[/COLOR]": "http://cmanbuildsxyz.com/neo/neo.m3u8",
    "[COLORlime]Rakuten TV[/COLOR]": "https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/uk_rakuten.m3u",
    "[COLORlime]Samsung TV[/COLOR]": "https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/refs/heads/main/playlists/samsungtvplus_gb.m3u",
    "[COLORlime]Tubi TV[/COLOR]": "https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_tubi.m3u",
    "[COLORlime]Xumo TV[/COLOR]": "https://raw.githubusercontent.com/BuddyChewChew/xumo-playlist-generator/refs/heads/main/playlists/xumo_playlist.m3u"
}

BLOCKED_KEYWORDS = ['gettv', 'mlb', 'nba', 'nfl', 'nhl', 'ppv', 'sky', 'sportsman', 'pluto', '&TV', '[Not 24/7]', '[Geo-blocked]', 'Fox News Channel', 'FETV', 'Opportunities in Urban Renaissance Television (OURTV)', 'Village of Hastings-On-Hudson NY (WHOH-TV)', 'WVCU-LP Concord University Radio The Cure 97.7', '24Kitchen Serbia', '6 Wise Tv','vs', 'New K.Movies', 'RomCom K-Drama']

seen_titles_global = set()

def log(message, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_NAME} v{ADDON_VERSION}] {message}", level)

def xor_encrypt_decrypt(data):
    key_length = len(XOR_KEY)
    return bytes([data[i] ^ XOR_KEY[i % key_length] for i in range(len(data))])

def ensure_cache_dir():
    if not xbmcvfs.exists(CACHE_DIR):
        xbmcvfs.mkdirs(CACHE_DIR)

def load_cache():
    ensure_cache_dir()
    
    if not xbmcvfs.exists(CACHE_FILE):
        return {}
    
    try:
        with open(CACHE_FILE, 'rb') as f:
            encrypted_data = f.read()
        
        if not encrypted_data:
            return {}
        
        decrypted_data = xor_encrypt_decrypt(encrypted_data)
        cache_data = json.loads(decrypted_data.decode('utf-8'))
        
        current_time = time.time()
        cleaned_cache = {}
        
        for source_name, cache_entry in cache_data.items():
            if current_time - cache_entry.get('timestamp', 0) <= CACHE_DURATION:
                cleaned_cache[source_name] = cache_entry
        
        if len(cleaned_cache) != len(cache_data):
            save_cache(cleaned_cache)
        
        return cleaned_cache
    except Exception as e:
        log(f"Error loading cache: {str(e)}", xbmc.LOGERROR)
        return {}

def save_cache(cache_data):
    try:
        ensure_cache_dir()
        json_data = json.dumps(cache_data).encode('utf-8')
        encrypted_data = xor_encrypt_decrypt(json_data)
        
        with open(CACHE_FILE, 'wb') as f:
            f.write(encrypted_data)
        log("Cache saved and encrypted successfully")
    except Exception as e:
        log(f"Error saving cache: {str(e)}", xbmc.LOGERROR)

def get_cached_channels(source_name):
    cache_data = load_cache()
    
    if source_name in cache_data:
        cache_entry = cache_data[source_name]
        if time.time() - cache_entry.get('timestamp', 0) <= CACHE_DURATION:
            log(f"Using cached data for: {source_name}")
            return cache_entry.get('channels', [])
    
    return None

def cache_channels(source_name, channels):
    cache_data = load_cache()
    
    cache_data[source_name] = {
        'timestamp': time.time(),
        'channels': channels
    }
    
    save_cache(cache_data)
    log(f"Cached {len(channels)} channels for: {source_name}")

def clear_cache():
    if xbmcvfs.exists(CACHE_FILE):
        xbmcvfs.delete(CACHE_FILE)
        log("Cache cleared successfully")
        return True
    return False

def get_url(**kwargs):
    return f"{sys.argv[0]}?{urllib.parse.urlencode(kwargs)}"

def contains_blocked_keywords(title):
    if not title:
        return False
    
    title_lower = title.lower()
    for keyword in BLOCKED_KEYWORDS:
        if keyword.lower() in title_lower:
            log(f"Blocked channel '{title}' due to keyword: {keyword}")
            return True
    return False

def contains_ascii_characters(title):
    if not title:
        return False
    
    try:
        title.encode('ascii')
        return False
    except (UnicodeEncodeError, UnicodeDecodeError):
        log(f"Blocked channel '{title}' due to non-ASCII characters")
        return True

def contains_at_character(title):
    if not title:
        return False
    
    if '@' in title:
        log(f"Blocked channel '{title}' due to @ character")
        return True
    return False

def should_skip_channel(title):
    if not title:
        return True
    
    if contains_blocked_keywords(title):
        return True
    
    if contains_ascii_characters(title):
        return True
    
    if contains_at_character(title):
        return True
    
    skip_patterns = [
        r'^\d{1,2}:\d{2}',
        r'^\d{4}-\d{2}-\d{2}',
        r'https?://',
        r'\.(jpg|jpeg|png|gif|bmp|webp)$',
        r'^\s*$',
    ]
    
    title_lower = title.lower() if title else ""
    
    for pattern in skip_patterns:
        if re.search(pattern, title_lower):
            return True
    
    if len(title.strip()) < 3:
        return True
    
    return False

def clean_title(title):
    if not title:
        return title
    
    title = re.sub(r'\.(ts|m3u8|mp4|avi|mkv|jpg|jpeg|png|gif)$', '', title, flags=re.IGNORECASE)
    title = re.sub(r'\[[^\]]*?(?:HD|SD|FHD|UHD|4K|1080|720|480)[^\]]*?\]', '', title, flags=re.IGNORECASE)
    title = re.sub(r'\([^\)]*?(?:HD|SD|FHD|UHD|4K|1080|720|480)[^\)]*?\)', '', title, flags=re.IGNORECASE)
    title = re.sub(r'\b(?:HD|SD|FHD|UHD|4K|1080p|720p|480p)\b', '', title, flags=re.IGNORECASE)
    title = re.sub(r'\s+', ' ', title).strip()
    title = re.sub(r'[\s\-:\|]+$', '', title)
    title = re.sub(r'^[\s\-:\|]+', '', title)
    
    return title

def fetch_playlist_content(url):
    try:
        req = urllib.request.Request(url, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive'
        })
        
        with urllib.request.urlopen(req, timeout=20) as response:
            if response.status == 200:
                return response.read().decode('utf-8')
            else:
                log(f"HTTP Error {response.status} for URL: {url}", xbmc.LOGERROR)
                return None
                
    except urllib.error.URLError as e:
        log(f"URL Error fetching playlist: {str(e)}", xbmc.LOGERROR)
        return None
    except Exception as e:
        log(f"Error fetching playlist: {str(e)}", xbmc.LOGERROR)
        return None

def parse_m3u_playlist(content, source_name=""):
    if not content:
        return []
    
    channels = []
    lines = content.split('\n')
    current_channel = {}
    
    for line in lines:
        line = line.strip()
        
        if not line:
            continue
            
        if line.startswith('#EXTM3U') or line.startswith('#EXTVLCOPT'):
            continue
            
        if line.startswith('#EXTINF:'):
            parts = line.split(',', 1)
            if len(parts) > 1:
                title = parts[1].strip()
                title = clean_title(title)
                
                if should_skip_channel(title):
                    current_channel = {}
                    continue
                    
                current_channel = {
                    'title': title,
                    'source': source_name
                }
                
        elif (line.startswith('http') or line.startswith('https')) and current_channel:
            current_channel['url'] = line
            current_channel['thumbnail'] = ADDON_ICON
            current_channel['fanart'] = ADDON_FANART
            
            channels.append(current_channel)
            current_channel = {}
    
    return channels

def get_channels_from_source(source_name, force_refresh=False):
    global seen_titles_global
    seen_titles_global = set()
    
    if not force_refresh:
        cached_channels = get_cached_channels(source_name)
        if cached_channels is not None:
            return cached_channels
    
    playlist_url = PLAYLIST_SOURCES.get(source_name)
    if not playlist_url:
        return []
    
    log(f"Fetching playlist: {source_name}")
    content = fetch_playlist_content(playlist_url)
    
    if content:
        channels = parse_m3u_playlist(content, source_name)
        
        filtered_channels = []
        for channel in channels:
            title = channel['title']
            title_lower = title.lower()
            
            if (contains_blocked_keywords(title) or 
                contains_ascii_characters(title) or 
                contains_at_character(title) or
                title_lower in seen_titles_global):
                continue
            
            seen_titles_global.add(title_lower)
            filtered_channels.append(channel)
        
        log(f"Found {len(filtered_channels)} filtered channels from {source_name}")
        
        cache_channels(source_name, filtered_channels)
        
        return filtered_channels
    else:
        log(f"Failed to fetch playlist: {source_name}", xbmc.LOGERROR)
        
        cached_channels = get_cached_channels(source_name)
        if cached_channels:
            log(f"Using expired cache as fallback for: {source_name}")
            return cached_channels
        
        return []

def detect_stream_type(url):
    url_lower = url.lower()
    
    if '.m3u8' in url_lower or 'hls' in url_lower:
        return 'hls'
    
    if '.mpd' in url_lower or 'dash' in url_lower:
        return 'dash'
    
    if '.mp4' in url_lower or 'mp4' in url_lower:
        return 'mp4'
    
    if 'm3u8' in url_lower or 'live' in url_lower or 'stream' in url_lower:
        return 'hls'
    
    return 'http'

def setup_inputstream(list_item, url, stream_type='hls'):
    if not HAS_INPUTSTREAM_HELPER:
        return False
        
    if stream_type == 'hls':
        is_helper = inputstreamhelper.Helper('hls')
        if is_helper.check_inputstream():
            list_item.setProperty('inputstream', 'inputstream.adaptive')
            list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            list_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
            list_item.setProperty('inputstream.adaptive.stream_headers', f'User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
            return True
    
    elif stream_type == 'dash':
        is_helper = inputstreamhelper.Helper('mpd')
        if is_helper.check_inputstream():
            list_item.setProperty('inputstream', 'inputstream.adaptive')
            list_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            return True
    
    return False

def play_channel(url):
    try:
        stream_type = detect_stream_type(url)
        log(f"Playing stream: {url} (type: {stream_type})")
        
        list_item = xbmcgui.ListItem(path=url)
        list_item.setProperty('IsPlayable', 'true')
        
        if stream_type == 'hls':
            list_item.setMimeType('application/vnd.apple.mpegurl')
            list_item.setContentLookup(False)
            setup_inputstream(list_item, url, 'hls')
            
        elif stream_type == 'dash':
            list_item.setMimeType('application/dash+xml')
            setup_inputstream(list_item, url, 'dash')
            
        elif stream_type == 'mp4':
            list_item.setMimeType('video/mp4')
            
        else:
            list_item.setMimeType('video/mp4')
        
        list_item.setProperty('inputstream.adaptive.stream_headers', 
                            f'User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
        
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        return True
        
    except Exception as e:
        log(f"Error playing stream {url}: {str(e)}", xbmc.LOGERROR)
        
        xbmcgui.Dialog().ok('Playback Error', 
                           f'Unable to play stream: {str(e)}', 
                           'The stream may be unavailable or require special handling.')
        
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return False

def show_landing_page():
    global seen_titles_global
    seen_titles_global = set()
    
    for source_name in PLAYLIST_SOURCES.keys():
        list_item = xbmcgui.ListItem(label=source_name)
        list_item.setArt({
            'thumb': ADDON_ICON,
            'icon': ADDON_ICON,
            'fanart': ADDON_FANART
        })
        list_item.setInfo('video', {
            'title': source_name,
            'plot': f'Browse channels from {source_name} only'
        })
        xbmcplugin.addDirectoryItem(HANDLE, get_url(action='source', source=source_name), list_item, isFolder=True)
    
    list_item = xbmcgui.ListItem(label="[COLOR lime]Manage Cache[/COLOR]")
    list_item.setArt({
        'thumb': ADDON_ICON,
        'icon': ADDON_ICON,
        'fanart': ADDON_FANART
    })
    list_item.setInfo('video', {
        'title': 'Manage Cache',
        'plot': 'Clear cached playlist data or refresh individual sources'
    })
    xbmcplugin.addDirectoryItem(HANDLE, get_url(action='manage_cache'), list_item, isFolder=True)
    
    xbmcplugin.setContent(HANDLE, 'files')
    xbmcplugin.endOfDirectory(HANDLE)

def show_cache_management():
    list_item = xbmcgui.ListItem(label="[COLOR red]Clear All Cache[/COLOR]")
    list_item.setArt({
        'thumb': ADDON_ICON,
        'icon': ADDON_ICON,
        'fanart': ADDON_FANART
    })
    list_item.setInfo('video', {
        'title': 'Clear All Cache',
        'plot': 'Clear all cached playlist data (will force refresh on next load)'
    })
    xbmcplugin.addDirectoryItem(HANDLE, get_url(action='clear_cache'), list_item, isFolder=False)
    
    for source_name in PLAYLIST_SOURCES.keys():
        list_item = xbmcgui.ListItem(label=f"Refresh: {source_name}")
        list_item.setArt({
            'thumb': ADDON_ICON,
            'icon': ADDON_ICON,
            'fanart': ADDON_FANART
        })
        list_item.setInfo('video', {
            'title': f'Refresh {source_name}',
            'plot': f'Force refresh and update cache for {source_name}'
        })
        xbmcplugin.addDirectoryItem(HANDLE, get_url(action='refresh_source', source=source_name), list_item, isFolder=True)
    
    list_item = xbmcgui.ListItem(label="[COLOR blue]Back to Main Menu[/COLOR]")
    list_item.setArt({
        'thumb': ADDON_ICON,
        'icon': ADDON_ICON,
        'fanart': ADDON_FANART
    })
    xbmcplugin.addDirectoryItem(HANDLE, get_url(action='landing'), list_item, isFolder=True)
    
    xbmcplugin.setContent(HANDLE, 'files')
    xbmcplugin.endOfDirectory(HANDLE)

def list_source_channels(source_name, force_refresh=False):
    channels = get_channels_from_source(source_name, force_refresh)
    
    if not channels:
        xbmcgui.Dialog().ok('Error', f'No channels found from {source_name}. Please check your internet connection and try again.')
        xbmcplugin.endOfDirectory(HANDLE)
        return
    
    channels.sort(key=lambda x: x['title'].lower())
    
    for channel in channels:
        title = channel.get('title', 'Unknown Channel')
        url = channel.get('url', '')
        thumbnail = channel.get('thumbnail', ADDON_ICON)
        
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt({
            'thumb': thumbnail,
            'icon': thumbnail,
            'fanart': ADDON_FANART
        })
        
        stream_type = detect_stream_type(url)
        
        list_item.setInfo('video', {
            'title': title,
            'plot': f'Live TV Channel: {title}\nSource: {source_name}\nStream Type: {stream_type.upper()}'
        })
        list_item.setProperty('IsPlayable', 'true')
        
        plugin_url = get_url(action='play', url=urllib.parse.quote(url))
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url, list_item, isFolder=False)
    
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)

def router(params):
    action = params.get('action', '')
    url = params.get('url', '')
    source = params.get('source', '')
    force_refresh = params.get('refresh', '') == 'true'
    
    if action == 'play' and url:
        play_channel(urllib.parse.unquote(url))
    elif action == 'source' and source:
        list_source_channels(source, force_refresh)
    elif action == 'refresh_source' and source:
        list_source_channels(source, force_refresh=True)
    elif action == 'manage_cache':
        show_cache_management()
    elif action == 'clear_cache':
        if clear_cache():
            xbmcgui.Dialog().ok('Cache Cleared', 'All cached playlist data has been cleared.')
        show_landing_page()
    else:
        show_landing_page()

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    router(params)